#include <stdio.h>
#include <stdlib.h>
#include <string.h> // Para memset
#include <unistd.h> // Para close
#include <time.h>
#include <arpa/inet.h> // Para inet_addr, htons, AF_INET, SOCK_STREAM

//#define PORTA 9990
#define PORTA 10000
#define IP_SERVIDOR "127.0.0.1"

void imprime_tabuleiro(char tabuleiro[3][3])
{
    printf("\t\t\t \t 0   1   2\n");
    printf("\n");
    printf("\t\t\t \t===========\n");
    for (int i = 0; i < 3; i++)
    {
        printf("\t\t\t%d\t %c | %c | %c\n", i, tabuleiro[i][0], tabuleiro[i][1], tabuleiro[i][2]);
        if (i < 2)
            printf("\t\t\t \t---+---+---\n");
    }
    printf("\t\t\t \t===========\n");
}

int ganhador(char tabuleiro[3][3], char simbolo)
{
    for (int i = 0; i < 3; i++)
    {
        if ((tabuleiro[i][0] == simbolo) && (tabuleiro[i][1] == simbolo) && (tabuleiro[i][2] == simbolo))
            return 1;
        if ((tabuleiro[0][i] == simbolo) && (tabuleiro[1][i] == simbolo) && (tabuleiro[2][i] == simbolo))
            return 1;
    }
    if ((tabuleiro[0][0] == simbolo) && (tabuleiro[1][1] == simbolo) && (tabuleiro[2][2] == simbolo))
        return 1;
    if ((tabuleiro[0][2] == simbolo) && (tabuleiro[1][1] == simbolo) && (tabuleiro[2][0] == simbolo))
        return 1;
    return 0;
}

int main()
{
    printf("=================================================================================\n");
    printf("                                      JOGO DA VELHA                              \n");
    printf("=================================================================================\n");

    int sock;
    struct sockaddr_in server;
    char jogador1[50], jogador2[50];
    //char mensagem[22];
    
    //int linha, coluna;
    //char tabuleiro[3][3];

    // Cria o socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1)
    {
        printf("Não foi possível criar o socket\n");
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(IP_SERVIDOR);
    server.sin_port = htons(PORTA);

    // Conecta ao servidor
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Erro de conexão");
        return 1;
    }

    printf("=================================================================================\n");
    printf("Informe o nome do jogador 1 = ");
    scanf("%49s", jogador1); // Use %49s para evitar buffer overflow
    printf("\nInforme o nome do jogador 2 = ");
    scanf("%49s", jogador2); // Use %49s para evitar buffer overflow
    printf("\n");
    printf("=================================================================================\n");

    int jogador;
    
    

    srand(time(NULL));
    jogador = (rand() % 10) + 1;
    
    printf("O número sorteado foi: %d\n", jogador);
    //printf("Iniciará o jogo o jogador [[[ %d ]]]\n", jogador);
    if (jogador == 0)
    {
        printf("Iniciará o jogo o jogador [[[ %s ]]]\n", jogador1);
    }
    else
    {
        printf("Iniciará o jogo o jogador [[[ %s ]]]\n", jogador2);
    }
    printf("=================================================================================\n");

    char tabuleiro[3][3] = {
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '}};

    int i, linha, coluna, vez = 0;
    char simbolo;

    imprime_tabuleiro(tabuleiro);
    
    char mensagem[8];

    // Envia os nomes dos jogadores para o servidor
    send(sock, jogador1, sizeof(jogador1), 0);
    send(sock, jogador2, sizeof(jogador2), 0);

    printf("Conectado ao servidor.\n");

    for (i = 0; i < 9; i++)
    {
        if (vez % 2 == 0){
            simbolo = 'X';
        }
        else
        {
            simbolo = 'O';
        }
        printf("=================================================================================\n");
        printf("Jogador %d [%c], digite linha [ESPAÇO] (0-2) coluna (0-2): ", vez % 2 + 1, simbolo);
        scanf("%d %d", &linha, &coluna);
        printf("=================================================================================\n");

        if ((linha < 0) || (linha > 2) || (coluna < 0) || (coluna > 2))
        {
            printf("Entrada invalida, tente novamente !!!\n");
            vez--;
        }
        else if (tabuleiro[linha][coluna] != ' ')
        {
            printf("Essa posição, esta ocupada !!!\n");
            vez--;
        }
        else
        {
            tabuleiro[linha][coluna] = simbolo;
            imprime_tabuleiro(tabuleiro);

            // Envia a jogada para o servidor
            if (send(sock, &linha, sizeof(int), 0) < 0 || send(sock, &coluna, sizeof(int), 0) < 0)
            {
                perror("Erro ao enviar jogada");
                break;
            }

            // Recebe o tabuleiro atualizado do servidor
            if (recv(sock, tabuleiro, sizeof(tabuleiro), 0) < 0)
            {
                perror("Erro ao receber tabuleiro");
                break;
            }

            // Recebe a mensagem do servidor (VENCEDOR ou CONTINUE)
            if (recv(sock, mensagem, sizeof(mensagem), 0) < 0)
            {
                perror("Erro ao receber mensagem");
                break;
            }

        /*}
            
            if (ganhador(tabuleiro, simbolo))
            {
                printf("=================================================================================\n");
                printf("Jogador %d  [%c] {{{ venceu }}} o jogo parabéns!\n", vez % 2 + 1, simbolo);
                printf("=================================================================================\n");
                // Pergunta ao jogador se deseja iniciar uma nova partida

                //printf("Deseja iniciar uma nova partida? (s/n): ");
                //scanf(" %c", &resposta);
//
                //if (resposta == 'n' || resposta == 'N')
                //{
                //    printf("=================================================================================\n");
                //    printf("                    FIM DE JOGO - COMPILAR O JOGO NOVAMENTE                      \n");
                //    printf("=================================================================================\n");
                //    printf("                               BY MAICON NUNES !!!                               \n");
                //    printf("=================================================================================\n");
                close(sock);
                return 0;

                }
                
                    printf("=================================================================================\n");
                    printf("Jogo empatado !!! ninguem ganhou\n");
                    printf("=================================================================================\n");
            }
        }

            vez++;
    }
        
    
    //char resposta;
    //printf("=================================================================================\n");
    //printf("Jogo empatado !!! ninguem ganhou\n");
    //printf("=================================================================================\n");

    char resposta;

    printf("Deseja iniciar uma nova partida? (s/n): ");
    scanf(" %c", &resposta);

    if (resposta == 'n' || resposta == 'N')
    {
        printf("=================================================================================\n");
        printf("                    FIM DE JOGO - COMPILAR O JOGO NOVAMENTE                      \n");
        printf("=================================================================================\n");
        printf("                               BY MAICON NUNES !!!                               \n");
        printf("=================================================================================\n");

        close(sock);
        return 0;
    
}*/

        if (ganhador(tabuleiro, simbolo))
        {
            printf("=================================================================================\n");
            printf("Jogador %d  [%c] {{{ venceu }}} o jogo parabéns!\n", vez % 2 + 1, simbolo);
            printf("=================================================================================\n");
            char resposta;

            printf("Deseja iniciar uma nova partida? (s/n): ");
            scanf(" %c", &resposta);
            if (resposta == 's' || resposta == 'S')
            {
                imprime_tabuleiro(tabuleiro);
            }
            //printf("                    FIM DE JOGO - COMPILAR O JOGO NOVAMENTE                      \n");
            //printf("=================================================================================\n");
            //printf("                               BY MAICON NUNES !!!                               \n");
            //printf("=================================================================================\n");
            return 0;
        }
        vez++;
        }

        
}

printf("=================================================================================\n");
printf("Jogo empatado !!! ninguem ganhou\n");
printf("=================================================================================\n");
char resposta;

printf("Deseja iniciar uma nova partida? (s/n): ");
scanf(" %c", &resposta);
if (resposta == 's' || resposta == 'S')
{
    imprime_tabuleiro(tabuleiro);
}
//printf("                    FIM DE JOGO - COMPILAR O JOGO NOVAMENTE                      \n");
//printf("=================================================================================\n");
//printf("                               BY MAICON NUNES !!!                               \n");
//printf("=================================================================================\n");

return 0;
}


    // Execute o cliente primeiro:
    //gcc - o cliente cliente.c
    //./cliente