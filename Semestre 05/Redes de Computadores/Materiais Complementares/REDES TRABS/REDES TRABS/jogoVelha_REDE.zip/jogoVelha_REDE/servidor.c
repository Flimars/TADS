#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <arpa/inet.h>

#define PORTA 10000
#define IP_SERVIDOR "127.0.0.1"

void imprime_tabuleiro(char tabuleiro[3][3])
{
    printf("\t\t\t \t 0   1   2\n");
    printf("\n");
    printf("\t\t\t \t===========\n");
    for (int i = 0; i < 3; i++)
    {
        printf("\t\t\t%d\t %c | %c | %c\n", i, tabuleiro[i][0], tabuleiro[i][1], tabuleiro[i][2]);
        if (i < 2)
            printf("\t\t\t \t---+---+---\n");
    }
    printf("\t\t\t \t===========\n");
}

int ganhador(char tabuleiro[3][3], char simbolo)
{
    for (int i = 0; i < 3; i++)
    {
        if ((tabuleiro[i][0] == simbolo) && (tabuleiro[i][1] == simbolo) && (tabuleiro[i][2] == simbolo))
            return 1;
        if ((tabuleiro[0][i] == simbolo) && (tabuleiro[1][i] == simbolo) && (tabuleiro[2][i] == simbolo))
            return 1;
    }
    if ((tabuleiro[0][0] == simbolo) && (tabuleiro[1][1] == simbolo) && (tabuleiro[2][2] == simbolo))
        return 1;
    if ((tabuleiro[0][2] == simbolo) && (tabuleiro[1][1] == simbolo) && (tabuleiro[2][0] == simbolo))
        return 1;
    return 0;
}

int main()
{
    int server_sock, client_sock, c;
    struct sockaddr_in server, client;
    char tabuleiro[3][3] = {
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '}};
    int vez = 0;
    char simbolo;
    int linha, coluna;

    // Declaração das variáveis dos jogadores
    int jogador;
    char jogador1[50], jogador2[50];

    // Cria o socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1)
    {
        printf("Não foi possível criar o socket\n");
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PORTA);

    // Associa o socket ao endereço e porta
    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Erro de bind");
        return 1;
    }

    // Escuta conexões
    listen(server_sock, 2);

    printf("Aguardando conexões...\n");
    c = sizeof(struct sockaddr_in);

    // Aceita conexões de clientes
    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, (socklen_t *)&c)))
    {
        printf("Conexão aceita\n");

        printf("=================================================================================\n");
        printf("                                      JOGO DA VELHA                              \n");
        printf("=================================================================================\n");

        // Recebe os nomes dos jogadores do cliente
        if (recv(client_sock, jogador1, sizeof(jogador1), 0) <= 0)
        {
            perror("Erro ao receber o nome do jogador 1");
            break;
        }
        if (recv(client_sock, jogador2, sizeof(jogador2), 0) <= 0)
        {
            perror("Erro ao receber o nome do jogador 2");
            break;
        }

        // Determina o jogador que começa com base no valor de `vez`
        jogador = (jogador % 2 == 0) ? 1 : 2; // Alterna o jogador

        // Imprime qual jogador iniciará o jogo
        if (jogador == 0)
        {
            printf("Iniciará o jogo o jogador [[[ %s ]]]\n", jogador1);
        }
        else
        {
            printf("Iniciará o jogo o jogador [[[ %s ]]]\n", jogador2);
        }

        for (int i = 0; i < 9; i++)
        {
            // Recebe a jogada do cliente
            if (recv(client_sock, &linha, sizeof(int), 0) <= 0 || recv(client_sock, &coluna, sizeof(int), 0) <= 0)
            {
                perror("Erro ao receber jogada");
                break;
            }

            // Determina o símbolo baseado na vez
            simbolo = (vez % 2 == 0) ? 'X' : 'O';
            jogador = (vez % 2 == 0) ? 1 : 2; // Alterna o jogador

            // Exibe a jogada recebida
            if (jogador == 0)
            {
                printf("Jogada recebida do jogador [[[ %s ]]]: linha %d, coluna %d\n", jogador1, linha, coluna);
            }
            else
            {
                printf("Jogada recebida do jogador [[[ %s ]]]: linha %d, coluna %d\n", jogador2, linha, coluna);
            }

            // Atualiza o tabuleiro
            if (tabuleiro[linha][coluna] == ' ')
            {
                tabuleiro[linha][coluna] = simbolo;
            }

            // Imprime o tabuleiro atualizado no servidor
            imprime_tabuleiro(tabuleiro);

            // Verifica se há um vencedor
            if (ganhador(tabuleiro, simbolo))
            {
                printf("Jogador com símbolo '%c' venceu!\n", simbolo);
                send(client_sock, tabuleiro, sizeof(tabuleiro), 0);
                send(client_sock, "VENCEDOR", 8, 0); // Envia a mensagem de vitória
                send(client_sock, "FIM", 3, 0);      // Envia a mensagem de fim de jogo
                break;
            }
            else
            {
                send(client_sock, tabuleiro, sizeof(tabuleiro), 0);
                if (i == 8) // Verifica se é a última jogada (empate)
                {
                    printf("Jogo empatado !!!\n");
                    send(client_sock, "EMPATE", 6, 0); // Envia mensagem de empate
                    send(client_sock, "FIM", 3, 0);    // Envia a mensagem de fim de jogo
                    break;
                }
                else
                {
                    send(client_sock, "CONTINUE", 8, 0); // Envia uma mensagem para continuar
                }
            }

            vez++;
        }

        // Encerra a conexão com o cliente após o jogo
        printf("Fim do jogo. Conexão encerrada.\n");
        close(client_sock);
    }

    if (client_sock < 0)
    {
        perror("Erro ao aceitar conexão");
        return 1;
    }

    close(server_sock);
    return 0;
}

// gcc -o servidor servidor.c
//./servidor