#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct operacao
{
    int id;
    char site[30];
} Operacao;

typedef struct elemento
{
    Operacao navegar;
    struct elemento *anterior;
    struct elemento *proximo;
} Elemento;

typedef struct LDE
{
    Elemento *primeiro;
    int n;
} LDE;

    //// Protótipos das funções
    LDE *criaListaLDE();
    Elemento *criaElemento(int id, char site[]);
    Elemento *criaElemento1(Operacao op);
    void insereNoInicio(LDE *ls, Elemento *novo);
    void insereNoFim(LDE *ls, Elemento *novo);
    int insereNaPosicao(LDE *ls, Elemento *novo, int pos);
    Elemento *removeInicio(LDE *ls);
    Elemento *removeNoFim(LDE *ls);
    Elemento *removeNaPosicao(LDE *ls, int pos);
    void mostraDados(Operacao d);
    void mostraListaED(LDE *ls);
    void mostraListaDE(LDE *ls);
    void mostraElementoPosicao(LDE *ls, int pos);
    void apagarLDE(LDE *ls);
    void apagarElemento(Elemento *e);
    void menu(LDE *ls);

    LDE *criaListaLDE()
    {
    LDE *ls = (LDE *)malloc(sizeof(LDE));
    ls->primeiro = NULL;
    ls->n = 0;
    return ls;
    }

    Elemento *criaElemento(int id, char site[])
    {
    Elemento *e = (Elemento *)malloc(sizeof(Elemento));
    e->navegar.id = id;
    strcpy(e->navegar.site, site);
    e->anterior = NULL;
    e->proximo = NULL;
    return e;
    }

    /*Elemento *criaElemento1(Operacao op)
    {
    Elemento *e = (Elemento *)malloc(sizeof(Elemento));
    e->navegar = op;
    e->anterior = NULL;
    e->proximo = NULL;
    return e;
    }*/

    void insereNoInicio(LDE *ls, Elemento *novo)
    {
    if (ls == NULL || novo == NULL)
        return;
    novo->anterior = NULL;
    novo->proximo = ls->primeiro;
    if (ls->primeiro != NULL)
        ls->primeiro->anterior = novo;
    ls->primeiro = novo;
    ls->n++;
    }

    void insereNoFim(LDE *ls, Elemento *novo)
    {
    if (ls == NULL || novo == NULL)
        return;
    novo->anterior = NULL;
    novo->proximo = NULL;
    if (ls->primeiro == NULL)
    {
        ls->primeiro = novo;
    }
    else
    {
        Elemento *ultimo = ls->primeiro;
        while (ultimo->proximo != NULL)
        {
            ultimo = ultimo->proximo;
        }
        novo->anterior = ultimo;
        ultimo->proximo = novo;
    }
    ls->n++;
    }

    int insereNaPosicao(LDE *ls, Elemento *novo, int pos)
    {
    if (ls == NULL || novo == NULL)
        return 0;
    if (pos <= 0 || pos > ls->n + 1)
        return 0;
    if (pos == 1)
    {
        insereNoInicio(ls, novo);
        return 1;
    }
    if (pos == ls->n + 1)
    {
        insereNoFim(ls, novo);
        return 1;
    }
    Elemento *atual = ls->primeiro;
    int i;
    for (i = 1; i < pos; i++)
    {
        atual = atual->proximo;
    }
    novo->anterior = atual->anterior;
    novo->proximo = atual;
    atual->anterior->proximo = novo;
    atual->anterior = novo;
    ls->n++;
    return 1;
    }

    // Função para remover o primeiro elemento da lista
    Elemento *removeInicio(LDE *ls)
    {
    if (ls == NULL || ls->primeiro == NULL)
        return NULL;
    Elemento *removido = ls->primeiro;
    ls->primeiro = removido->proximo;
    if (ls->primeiro != NULL)
        ls->primeiro->anterior = NULL;
    removido->anterior = NULL;
    removido->proximo = NULL;
    ls->n--;
    return removido;
    }

    Elemento *removeNoFim(LDE *ls)
    {
    if (ls == NULL || ls->primeiro == NULL)
        return NULL;
    Elemento *removido;
    if (ls->primeiro->proximo == NULL)
    {
        removido = ls->primeiro;
        ls->primeiro = NULL;
    }
    else
    {
        Elemento *ultimo = ls->primeiro;
        while (ultimo->proximo != NULL)
        {
            ultimo = ultimo->proximo;
        }
        removido = ultimo;
        ultimo->anterior->proximo = NULL;
    }
    removido->anterior = NULL;
    removido->proximo = NULL;
    ls->n--;
    return removido;
    }

    Elemento *removeNaPosicao(LDE *ls, int pos)
    {
    if (ls == NULL || ls->primeiro == NULL || pos <= 0 || pos > ls->n)
        return NULL;
    Elemento *removido;
    if (pos == 1)
    {
        removido = ls->primeiro;
        ls->primeiro = removido->proximo;
        if (ls->primeiro != NULL)
            ls->primeiro->anterior = NULL;
    }
    else
    {
        Elemento *atual = ls->primeiro;
        int i;
        for (i = 1; i < pos; i++)
        {
            atual = atual->proximo;
        }
        removido = atual;
        atual->anterior->proximo = atual->proximo;
        if (atual->proximo != NULL)
            atual->proximo->anterior = atual->anterior;
    }
    removido->anterior = NULL;
    removido->proximo = NULL;
    ls->n--;
    return removido;
    }

    void mostraDados(Operacao d)
    {
    printf("ID: %d\nSite: %s\n", d.id, d.site);
    }

        // Função para mostrar a lista da esquerda para direita
    void mostraListaED(LDE *ls)
    {
    if (ls != NULL)
    {
        Elemento *atual = ls->primeiro;
        while (atual != NULL)
        {
            mostraDados(atual->navegar);
            atual = atual->proximo;
        }
    }
    }

    void mostraListaDE(LDE *ls)
    {
    if (ls != NULL)
    {
        Elemento *atual = ls->primeiro;
        while (atual->proximo != NULL)
        {
            atual = atual->proximo;
        }
        while (atual != NULL)
        {
            mostraDados(atual->navegar);
            atual = atual->anterior;
        }
    }
    }

    void mostraElementoPosicao(LDE *ls, int pos)
    {
    if (ls != NULL && pos >= 1 && pos <= ls->n)
    {
        Elemento *atual = ls->primeiro;
        for (int i = 1; i < pos; i++)
        {
            atual = atual->proximo;
        }
        mostraDados(atual->navegar);
    }
    }

    // Função para apagar toda a lista
    void apagarLDE(LDE *ls)
    {
        Elemento *aux = ls->primeiro;
        while (aux != NULL)
        {
        Elemento *removido = removeInicio(ls);
        free(removido);
        }
        //ls->primeiro = NULL;
        //ls->n = 0;
    }
    
    // Função para apagar um elemento
    void apagarElemento(Elemento *e)
    {
        free(e);
    }

        // Função para exibir o menu de opções
        void menu(LDE *ls)
        {
            int opcao = 0;
                while (opcao != 10)
                {
        // system("clear");
        printf("\n\nInforme uma Opção:");
        printf("\n -- 1 - Cadastrar nova operação - SITE :");
        printf("\n -- 2 - CTRL+Z - DESFAZER ultima operação :");
        printf("\n -- 3 - CTRL+Y - REFAZER ultima operação :");
        printf("\n -- 4 - Mostra primeira operação cadastrada :");
        printf("\n -- 5 - Mostra a ultima operação cadastrada :");
        printf("\n -- 6 - Mostra uma operação na posição :");
        printf("\n -- 7 - Mostra a Lista ED :");
        printf("\n -- 8 - Mostra a Lista DE :");
        printf("\n -- 9 - Apagar uma operação na posição :");
        printf("\n -- 10 - Apagar Lista:");
        printf("\n -- 0 - para Sair do Programa:\n");
        printf("\nInforme sua Opçao:");
        scanf("%d", &op);
        fflush(stdin);

        int id;
        char site[30];
        int pos;
        switch (opcao)
        {
        case 1:
            printf("Digite o ID da operação:\n");
            scanf("%d", &id);
            printf("Digite o nome do site:\n");
            scanf("%s", site);
            op.id = id; // atualiza o valor de id em op
            strcpy(op.site, site);
            Elemento *novo = criaElemento1(op);
            insereNoInicio(ls, novo);
            printf("Elemento inserido no início da lista!\n");
            break;

        case 2:
            printf("Digite o ID da operação:\n");
            scanf("%d", &id);
            printf("Digite o nome do site:\n");
            scanf("%s", site);
            op.id = id; // atualiza o valor de id em op
            strcpy(op.site, site);
            Elemento *novo = criaElemento1(op);
            insereNoFim(ls, novo);
            printf("Elemento inserido no fim da lista!\n");
            break;

        case 3:
            printf("Digite o ID da operação:\n");
            scanf("%d", &id);
            printf("Digite o nome do site:\n");
            scanf("%s", site);
            op.id = id; // atualiza o valor de id em op
            strcpy(op.site, site);
            Elemento *novo = criaElemento1(op);
            if (insereNaPosicao(ls, novo, pos))
            {
                printf("Elemento inserido na posição %d da lista!\n", pos);
            }
            else
            {
                printf("Posição inválida!\n");
            }
            break;

        case 4:

            removeDoInicio(ls);
            printf("Elemento removido do início da lista!\n");
            break;

        case 5:

            removeDoFim(ls);
            printf("Elemento removido do fim da lista!\n");
            break;

        case 6:

            int pos;
            printf("Digite a posição do elemento que será removido:\n");
            scanf("%d", &pos);
            if (removeDaPosicao(ls, pos))
            {
                printf("Elemento removido da posição %d da lista!\n", pos);
            }
            else
            {
                printf("Posição inválida!\n");
            }
            break;

        case 7:

            mostraLista(ls);
            break;

        case 8:

            printf("Encerrando o programa...\n");
            apagarLDE(ls);
            break;

        default:

            printf("Opção inválida!\n");
            break;
                        
                    }
                }
    }
    int main()
    {
                LDE *ls = criaListaLDE();
                //Elemento *criaElemento(Operacao op);
                menu(ls);
                apagarLDE(ls);
                return 0;
    }
