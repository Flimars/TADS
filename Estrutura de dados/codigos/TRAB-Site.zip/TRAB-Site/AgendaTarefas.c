#include <stdio.h>
#include <stdlib.h>

typedef struct tarefa
{
    char descricao[30];
    int id, prioridade;
} Tarefa;

typedef struct elemento
{
    Tarefa tf;
    struct elemento *anterior;
    struct elemento *proximo;
} Elemento;

typedef struct LDE
{
    Elemento *primeiro;
    int n;
} LDE;

/*LDE *criaListaLDE();
Elemento *criaElemento(int id);

void insereNoInicio(LDE *l, Elemento *tf);
void insereNoFim(LDE *l, Elemento *tf);
int insereNaPosicao(LDE *l, Elemento *tf, int p);

Elemento *removeNoInicio(LDE *l);
Elemento *removeNoFim(LDE *l);
Elemento *removeNaPosicao(LDE *l, int p);

void mostraDados(Elemento d);*/

//void mostraListaED(LDE *l); // mostra da Esquerda para Direita
void mostraListaDE(LDE *l); // mostra da Direita para Esquerda

/*void mostraElementoPosicao(LDE *l, int posicao);

void apagaLDE(LDE *l);

void menu(LDE *l);*/

LDE *criaListaLDE()
{
    // aloca espaço para gerenciar a nova lista
    LDE *nova = (LDE *)malloc(sizeof(LDE));
    nova->primeiro = NULL;
    nova->n = 0;
    return nova;
}

Elemento *criaElemento(int id)
{
    // aloca memória para um novo elemento, e preenche os campos
    Elemento *nova = (Elemento *)malloc(sizeof(Elemento));
    nova->tf.id = id;
    fflush(stdin);
    printf("Informe sua Prioridade:");
    scanf("%d", &nova->tf.prioridade);
    printf("Informe a Descricao:");
    scanf("%s", nova->tf.descricao);
    printf("Elemento Criada com Sucesso\n ");
    return nova;
}

void insereNoInicio(LDE *l, Elemento *el)
{
    // insere um elemento no início da lista
    printf("\nInsere no INICIO\n");
    el->anterior = NULL;
    if (l->primeiro == NULL)
    {
        el->proximo = NULL;
    }
    else
    {
        el->proximo = l->primeiro;
        l->primeiro->anterior = el; // Corrigir
    }
    l->primeiro = el;
    l->n++;
}

void insereNoFim(LDE *l, Elemento *el)
{
    // insere um elemento no Fim da lista
    printf("\nInsere no FIM\n");
    Elemento *aux = l->primeiro;
    if (l->primeiro == NULL)
        insereNoInicio(l, el);
    else
    {
        while (aux->proximo != NULL)
        {
            aux = aux->proximo;
        }
        aux->proximo = el;
        el->anterior = aux;
        el->proximo = NULL;
        l->n++;
    }
}

int insereNaPosicao(LDE *l, Elemento *el, int p)
{
    // insere um novo elemento em uma posicao p, retorna 1 se a inserção na posição pode ser realizada
    printf("\nInsere na POSICAO %d\n", p);
    if (p < 1 || p > l->n + 1)
        return 0;
    if (p == 1)
        insereNoInicio(l, el);
    else if (p == l->n + 1)
        insereNoFim(l, el);
    else
    {
        Elemento *aux = l->primeiro;
        for (int i = 1; i < p - 1; i++)
        {
            aux = aux->proximo;
        }
        el->proximo = aux->proximo;
        el->anterior = aux;
        aux->proximo = el;
        el->proximo->anterior = el;
        l->n++;
    }
    return 1;
}


Elemento *removeNoInicio(LDE *l)
{
    // remove um elemento no inicio da lista
    printf("\nRemove no Início\n");
    Elemento *aux = l->primeiro;
    if (aux == NULL)
        return aux;
    l->primeiro = l->primeiro->proximo;
    if (l->primeiro != NULL)
        l->primeiro->anterior = NULL;
    aux->proximo = aux->anterior = NULL;
    l->n--;
    return aux;
}

Elemento *removeNoFim(LDE *l)
{
    // remove um elemento no fim da lista
    printf("\nRemove no FIM\n");
    if (l->primeiro == NULL)
        return NULL;
    Elemento *aux = l->primeiro;
    while (aux->proximo != NULL)
    {
        aux = aux->proximo;
    }
    if (aux->anterior != NULL)
        aux->anterior->proximo = NULL;
    else
        l->primeiro = NULL;
    aux->anterior = NULL;
    l->n--;
    return aux;
}

Elemento *removeNaPosicao(LDE *l, int p)
{
    // remove um elemento de uma posição p, retorna o elemento
    printf("\nRemove na POSICAO %d\n", p);
    if (p < 1 || p > l->n)
        return NULL;
    if (p == 1)
        return removeNoInicio(l);
    if (p == l->n)
        return removeNoFim(l);
    Elemento *aux = l->primeiro;
    for (int i = 1; i < p; i++)
    {
        aux = aux->proximo;
    }
    aux->anterior->proximo = aux->proximo;
    aux->proximo->anterior = aux->anterior;
    aux->proximo = aux->anterior = NULL;
    l->n--;
    return aux;
}

void mostraDados(Elemento el)
{
    // mostra um elemento do tipo tarefa
    printf("\n\tTarefa ID: %d", el.tf.id);
    printf("\n\tDescrição:  %s", el.tf.descricao);
    printf("\n\tPrioridade: %d\n", el.tf.prioridade);
}

void mostraListaED(LDE *l)
{
    // mostra lista da Esquerda para Direita
    system("clear");
    int pos = 1;
    // verifica se a lista está vazia
    if (l->n == 0)
    {
        printf("Lista vazia\n");
        return;
    }
    Elemento *aux = l->primeiro;
    while (aux != NULL)
    {
        printf("\nPosição: %d", pos++);
        mostraDados(*aux);
        aux = aux->proximo;
    }
    printf("\nFim da Lista de Tarefas 1-p/continuar\n");
    int d;
    scanf("%d", &d);
}

void mostraListaDE(LDE *l)
{
    system("clear");
    int pos = l->n;
    // verifica se a lista está vazia
    if (l->n == 0)
    {
        printf("Lista vazia\n");
        return;
    }
    // inicia o ponteiro auxiliar no último elemento
    Elemento *aux = l->primeiro;
    // percorre a lista do último elemento ao primeiro elemento
    while (aux->proximo != NULL)
    {
        aux = aux->proximo; // atualiza o ponteiro auxiliar
    }
    // percorre a lista do último elemento ao primeiro elemento
    while (aux != NULL)
    {
        printf("\nPosição: %d", pos);
        mostraDados(*aux);
        aux = aux->anterior;
        pos--; // atualiza o ponteiro auxiliar
    }
    printf("\n"); // imprime uma nova linha após a lista
}

void mostraElementoPosicao(LDE *l, int p)
{
    // mostra uma elemento na posição p
    system("clear");
    int pos = 1;
    Elemento *aux = l->primeiro;
    while (aux != NULL && pos < p)
    {
        aux = aux->proximo;
        pos++;
    }
    if (aux == NULL)
    {
        printf("\nElemento não encontrado na posição %d\n", p);
    }
    else
    {
        printf("\nElemento na posição %d:\n", p);
        mostraDados(*aux);
    }
}

void apagaLDE(LDE *l)
{
    // apaga todos os elementos da lista
    while (l->primeiro != NULL)
    {
        Elemento *removido = removeNoInicio(l);
        free(removido);
    }
}

void menu(LDE *l)
{
    int op, posicao, id = 1;
    Elemento *el;
    char ch;
    do
    {
        // system("clear");
        printf("\n\nInforme uma Opção:");
        printf("\n -- 1 - para Inserir Tarefa no Início:");
        printf("\n -- 2 - para Inserir Tarefa no Fim:");
        printf("\n -- 3 - Inserir Tarefa na Posição:");
        printf("\n -- 4 - para Remove Tarefa no Início:");
        printf("\n -- 5 - para Remove Tarefa no Fim:");
        printf("\n -- 6 - para Remove Tarefa na Posição:");
        printf("\n -- 7 - para Mostra um Tarefa da Posição:");
        printf("\n -- 8 - para Mostrar a Lista ED:");
        printf("\n -- 9 - para Mostrar a Lista DE:");
        printf("\n -- 10 - Apagar Lista:");
        printf("\n -- 0 - para Sair do Programa:\n");
        printf("\nInforme sua Opçao:");
        scanf("%d", &op);
        fflush(stdin);

        /// system("clear");

        switch (op)
        {
        case 1:
            printf("\n Inserção no Início. \n");
            insereNoInicio(l, criaElemento(id++));
            printf("\n Inserção Realizada com Sucesso");

            break;
        case 2:
            printf("\n Inserção no Fim. \n");
            insereNoFim(l, criaElemento(id++));
            printf("\n Inserção Realizada com Sucesso");

            break;
        case 3:
            printf("Insere na Posição, informa a posição:");
            scanf("%d", &posicao);
            fflush(stdin);
            int fl = insereNaPosicao(l, criaElemento(id++), posicao);
            fl == 1 ? printf("\n Inserção Realizada com Sucesso") : printf("\nERROR!!");
            break;
        case 4:
            printf("\nRemove no Início. \n");
            el = removeNoInicio(l);
            if (el != NULL)
            {
                printf("\n Remoção Realizada com Sucesso");
                mostraDados(*el);
            }
            else
            {
                printf("\nRemocao Não Realizada");
            }
            free(el);
            break;
        case 5:
            printf("\nRemove no Fim. \n");
            el = removeNoFim(l);
            if (el != NULL)
            {
                printf("\n Remoção Realizada com Sucesso");
                mostraDados(*el);
            }
            else
            {
                printf("\nRemocao Não Realizada");
            }
            free(el);
            break;
        case 6:
            printf("Remove na Posição, informa a posição:");
            scanf("%d", &posicao);
            fflush(stdin);
            el = removeNaPosicao(l, posicao);
            if (el != NULL)
            {
                printf("\n Remoção Realizada com Sucesso");
                mostraDados(*el);
            }
            else
            {
                printf("\nRemocao Não Realizada");
            }
            free(el);
            break;
        case 7:
            printf("Mostra Tarefa na Posição, informe a posição:");
            scanf("%d", &posicao);
            fflush(stdin);
            mostraElementoPosicao(l, posicao);

            break;
        case 8:
            printf("\nExibe Lista de Tarefas \n");
            mostraListaED(l);
            break;
        case 9:
            printf("\nExibe Lista de Tarefas \n");
            mostraListaDE(l);
            break;
        case 10:
            printf("\n Apagar a Lista !! \n");
            apagaLDE(l);
            break;
        case 0:
            op = -1;
            break;
        default:
            printf("\nOpção Inválida!!\n");
        }

    } while (op > 0);
}

int main(){
    
    printf("\n Exemplo de Lista Duplamente Encadeada!!");

    printf("\n Criando a LDE - Vazia  ");

    LDE *agenda = criaListaLDE();

    if(!agenda)
        exit(0);
    else
        printf("\n LDE Criada com Sucesso- Vazia\n");

    menu(agenda); //para gerenciar a aplicacao.

}