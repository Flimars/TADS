#include <stdio.h>
#include <stdlib.h>


void somaValores(int a, int b, int *pc){
    *pc = a + b;
}

void somaValores2(int *pa, int *pb){
    //a = a + b;
    *pa = *pa + *pb;
}

void somaValores3(int *pa, int *pb, int *pc){
    *pc = *pa + *pb;
}

int* somaValores4(int *pa, int *pb, int *ps){
    *ps = *pa + *pb;
    return ps;    
}



int main(){
    int a, b, c, s, *ps;
    a = 50;
    b = 70;
    s = 0;
    somaValores(a, b, &c );
    printf("\n A soma de %d com %d = %d\n",a,b,c);
    somaValores2(&a, &b);
    printf("\n A soma de A com B = %d\n",a);
    somaValores3(&a, &b, &s);
    printf("\n A soma de %d com %d = %d\n",a,b,s);
    s = 0;
    ps = (int*)somaValores4(&a, &b, &s);
    printf("\n A soma de %d com %d = %d\n",a,b,*ps);

    //printf("\n A soma de %d com %d = %d\n",a,b,*ps);

}