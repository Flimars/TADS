#include <stdio.h>
#include <stdlib.h>

#define n_elem 5 

void imprimeVetor(int vt[], int n){
    printf ("\n Função imprime vetor");
    printf("\n V = ["); 
    int i;
    for(i=0; i<n-1; i++){
        printf(" %d,",vt[i]);
    }
    printf(" %d ] \n",vt[i]);
}

void imprimeVetorInvertido(int vt[], int n){
    printf("\n Função imprime vetor Invertido ");
    printf("\n V = ["); 
    int i;
    for(i=n-1; i>0; i--){
        printf(" %d,",vt[i]);
    }
    printf(" %d ] \n",vt[i]);
}

// função com ponteiro de vetor
void imprimeVetorPonteiro(int *vt, int n){
    printf ("\n Função imprime vetor Ponteiro");
    printf("\n V = ["); 
    int i;
    for(i=0; i<n-1; i++){
        printf(" %d,",*(vt+i));
    }
    printf(" %d ] \n",*(vt+i));
}

// função com ponteiro de vetor
void imprimeVetorInvertidoPonteiro(int *vt, int n){
    printf("\n Função imprime vetor Invertido Ponteiro ");
    printf("\n V = ["); 
    int i;
    for(i=n-1; i>0; i--){
        printf(" %d,",*(vt+i));
    }
    printf(" %d ] \n",*(vt+i));
}

//Exercicio 1
int menorVetor(int *vt, int n){
    int menor = (int)(*vt);
    for(int i=1; i<n; i++){
        if(*(vt+i)<menor)
            menor = (int)*(vt+i);
    }
    return menor;
}

// //Exercicio 2
int maiorVetor(int *vt, int n){
    int maior = *vt;
    for(int i=1; i<n; i++){
        if(*(vt+i) > maior)
             maior = *(vt+i);
    }
    return maior;
}

// //Exercicio 3
// void menorMaiorVetor(int *vt, int n, int *menor, int *maior);

// //Exercicio 4
// int* menorVetorPonteiro(int *vt, int n);

// //Exercicio 5
// int* maiorVetorPonteiro(int *vt, int n);

//Exercicio 6
void menorMaiorVetor(int *vt, int n, int *vresposta){   
    //vetor resposta passagem por parâmetro
    vresposta[0] = menorVetor(vt,n);
    vresposta[1] = maiorVetor(vt,n);
}

int* menorMaiorVetor2(int *vt, int n){   
    //vetor resposta passagem por referência Necessita uso do MALLOC
    int *vresposta = malloc(sizeof(int)*2);
    vresposta[0] = menorVetor(vt,n);
    vresposta[1] = maiorVetor(vt,n);
    return vresposta;
}


int main(){       

    int v[5] = {3,-4,5,2,1}, n = 5;

    imprimeVetor(v,5);
    printf("\n Menor do Vetor %d",menorVetor(v,n));
    printf("\n Menor do Vetor %d",maiorVetor(v,n));

    //envio e retorno de um vetor preenchido
    int vMenorMaior [2];
    menorMaiorVetor(v,n,vMenorMaior);
    printf("\n Vetor com o menor e o maior valores\n");
    imprimeVetor(vMenorMaior,2);

    //retorno por referência
    int *vMenorMaior2;
    vMenorMaior2 = menorMaiorVetor2(v,n);
    printf("\n Vetor com o menor e o maior valores\n");
    imprimeVetor(vMenorMaior2,2);

}

