#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("\n Aula de Ponteiros!! \n");
    int *px = NULL;
   
    printf ("\n Valor px = %p \n",px);
}
