package br.edu.ifrs.riogrande.tads.cobaia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CobaiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
